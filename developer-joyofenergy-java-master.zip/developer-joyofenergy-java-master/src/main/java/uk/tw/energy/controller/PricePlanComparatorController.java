package uk.tw.energy.controller;

import javafx.util.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import uk.tw.energy.converter.PricePlanComparisonsPerPricePlanIdConverter;
import uk.tw.energy.domain.PricePlanComparisonsPerPricePlanId;
import uk.tw.energy.service.AccountService;
import uk.tw.energy.service.PricePlanService;

import java.math.BigDecimal;
import java.util.*;

@RestController
@RequestMapping("/price-plans")
public class PricePlanComparatorController {

    public final static String PRICE_PLAN_ID_KEY = "pricePlanId";
    public final static String PRICE_PLAN_COMPARISONS_KEY = "pricePlanComparisons";
  
    @Autowired
    private  PricePlanService pricePlanService;
    
    @Autowired
    private AccountService accountService;

    @Autowired
    private PricePlanComparisonsPerPricePlanIdConverter pricePlanComparisonsPerPricePlanIdConverter;


    @GetMapping("/compare-all/{smartMeterId}")
    public ResponseEntity<PricePlanComparisonsPerPricePlanId> calculatedCostForEachPricePlan(@PathVariable String smartMeterId) {
        String pricePlanId = accountService.getPricePlanIdForSmartMeterId(smartMeterId);
        Optional<Map<String, BigDecimal>> consumptionsForPricePlans =
                pricePlanService.getConsumptionCostOfElectricityReadingsForEachPricePlan(smartMeterId);
        if (!consumptionsForPricePlans.isPresent()) {
            return ResponseEntity.notFound().build();
        }
        Pair<String,Map<String, BigDecimal>>pricePlanConsumptionPerPricePlan=new Pair<>(pricePlanId,consumptionsForPricePlans.get());
        PricePlanComparisonsPerPricePlanId pricePlanComparisonsPerPricePlanId= pricePlanComparisonsPerPricePlanIdConverter.convert(pricePlanConsumptionPerPricePlan);
        return ResponseEntity.ok(pricePlanComparisonsPerPricePlanId);
    }

    @GetMapping("/recommend/{smartMeterId}")
    public ResponseEntity<List<Map.Entry<String, BigDecimal>>> recommendCheapestPricePlans(@PathVariable String smartMeterId,
                                                                                           @RequestParam(value = "limit", required = false) Integer limit) {
        Optional<Map<String, BigDecimal>> consumptionsForPricePlans =
                pricePlanService.getConsumptionCostOfElectricityReadingsForEachPricePlan(smartMeterId);

        if (!consumptionsForPricePlans.isPresent()) {
            return ResponseEntity.notFound().build();
        }

        List<Map.Entry<String, BigDecimal>> recommendations = new ArrayList<>(consumptionsForPricePlans.get().entrySet());
        recommendations.sort(Comparator.comparing(Map.Entry::getValue));

        if (limit != null && limit < recommendations.size()) {
            recommendations = recommendations.subList(0, limit);
        }

        return ResponseEntity.ok(recommendations);
    }
}
