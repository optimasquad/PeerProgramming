package uk.tw.energy.price.store;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import uk.tw.energy.domain.PricePlan;

import java.math.BigDecimal;
import java.time.DayOfWeek;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author JATIN MAHAJAN
 */
@Component
public class MostEvilPricePlan implements Plan {

    @Value("${evil.planName}")
    private String planName;

    @Value("${evil.energySupplier}")
    private String energySupplier;

    @Value("#{new Integer('${evil.unitRate}')}")
    private Integer unitRate;

    @Value("${evil.peakTimeMultiplier}")
    private List<String> peakTimeMultiplier;

    @Override
    public PricePlan getPricePlan() {
        List<PricePlan.PeakTimeMultiplier>peakTimeMultipliers=PricePlan.getPeakTimeMultiplier(peakTimeMultiplier);
//just log it to save the results
        return new PricePlan(planName, energySupplier, BigDecimal.TEN, Collections.emptyList());
    }
}
