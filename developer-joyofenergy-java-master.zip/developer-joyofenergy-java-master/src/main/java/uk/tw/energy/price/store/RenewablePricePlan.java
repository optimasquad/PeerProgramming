package uk.tw.energy.price.store;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import uk.tw.energy.domain.PricePlan;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;

@Component
public class RenewablePricePlan implements Plan {

	@Value("${renewable.planName}")
	private String planName;

	@Value("${renewable.energySupplier}")
	private String energySupplier;

	@Value("#{new Integer('${renewable.unitRate}')}")
	private Integer unitRate;

	@Value("${renewable.peakTimeMultiplier}")
	private List<String> peakTimeMultiplier;

	@Override
	public PricePlan getPricePlan() {
		return new PricePlan(planName, energySupplier, BigDecimal.valueOf(unitRate), Collections.emptyList());
	}

}
