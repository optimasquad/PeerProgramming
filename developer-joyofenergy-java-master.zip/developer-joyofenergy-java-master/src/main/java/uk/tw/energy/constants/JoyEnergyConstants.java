package uk.tw.energy.constants;

public final class JoyEnergyConstants {

	private JoyEnergyConstants() {
	}

	public static final String MOST_EVIL_PRICE_PLAN_ID = "price-plan-0";
	public static final String RENEWABLES_PRICE_PLAN_ID = "price-plan-1";
	public static final String STANDARD_PRICE_PLAN_ID = "price-plan-2";

}
