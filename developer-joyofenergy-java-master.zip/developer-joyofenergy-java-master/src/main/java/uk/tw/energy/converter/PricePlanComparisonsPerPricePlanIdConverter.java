package uk.tw.energy.converter;

import javafx.util.Pair;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import uk.tw.energy.domain.PricePlanComparisonsPerPricePlanId;

import java.math.BigDecimal;
import java.util.Map;

@Component
public class PricePlanComparisonsPerPricePlanIdConverter implements Converter<Pair<String, Map<String, BigDecimal>>, PricePlanComparisonsPerPricePlanId> {

    @Override
    public PricePlanComparisonsPerPricePlanId convert(Pair<String, Map<String, BigDecimal>> source) {
        return new PricePlanComparisonsPerPricePlanId(source.getKey(),source.getValue());
    }
}
