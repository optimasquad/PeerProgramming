package uk.tw.energy.exception;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

/**
 * @author JATIN MAHAJAN
 *
 */
@ControllerAdvice
public class ExceptionHandlerAdvice {

	@ExceptionHandler(InvalidPricePlanException.class)
	public ResponseEntity handleException(InvalidPricePlanException e) {
		return ResponseEntity.status(e.getHttpStatus()).body(e.getMessage());
	}

}
