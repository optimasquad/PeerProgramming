package uk.tw.energy.domain;

import java.math.BigDecimal;
import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class PricePlan {

	private final String energySupplier;
	private final String planName;
	private final BigDecimal unitRate; // unit price per kWh
	private final List<PeakTimeMultiplier> peakTimeMultipliers;

	public PricePlan(String planName, String energySupplier, BigDecimal unitRate, List<PeakTimeMultiplier> peakTimeMultipliers) {
		this.planName = planName;
		this.energySupplier = energySupplier;
		this.unitRate = unitRate;
		this.peakTimeMultipliers = peakTimeMultipliers;
	}

	public String getEnergySupplier() {
		return energySupplier;
	}

	public String getPlanName() {
		return planName;
	}

	public BigDecimal getUnitRate() {
		return unitRate;
	}

	public BigDecimal getPrice(LocalDateTime dateTime) {
		return peakTimeMultipliers.stream()
				.filter(multiplier -> multiplier.dayOfWeek.equals(dateTime.getDayOfWeek()))
				.findFirst()
				.map(multiplier -> unitRate.multiply(multiplier.multiplier))
				.orElse(unitRate);
	}


	public static class PeakTimeMultiplier {

		DayOfWeek dayOfWeek;
		BigDecimal multiplier;

		public PeakTimeMultiplier(DayOfWeek dayOfWeek, BigDecimal multiplier) {
			this.dayOfWeek = dayOfWeek;
			this.multiplier = multiplier;
		}
	}

	public static List<PricePlan.PeakTimeMultiplier> getPeakTimeMultiplier(List<String> perkTimeMultipliers) {
		List<PricePlan.PeakTimeMultiplier> peakTimeMultipliers = new ArrayList<>();
		for (String peakTime : perkTimeMultipliers) {
			String[] result = peakTime.split(";");
				String dayOfWeekValue=  result[0].replaceAll("dayOfWeek:","");
				String multiplierValue=  result[1].replaceAll("multiplier:","");
				peakTimeMultipliers.add(
						new PricePlan.PeakTimeMultiplier(DayOfWeek.of(Integer.valueOf(dayOfWeekValue)), BigDecimal.valueOf(Integer.valueOf(multiplierValue))));
		}
		return peakTimeMultipliers;
	}
}
