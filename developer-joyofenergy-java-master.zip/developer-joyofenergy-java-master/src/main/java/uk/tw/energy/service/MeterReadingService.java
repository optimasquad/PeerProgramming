package uk.tw.energy.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import uk.tw.energy.domain.ElectricityReading;
import uk.tw.energy.price.store.SuperMeter;

@Service
public class MeterReadingService {

	@Autowired
	private SuperMeter meter;

	public Optional<List<ElectricityReading>> getReadings(String smartMeterId) {
		return Optional.ofNullable(meter.getMeterReadingForMeterId(smartMeterId));
	}

	public void storeReadings(String smartMeterId, List<ElectricityReading> electricityReadings) {
		meter.storeMeterReadings(smartMeterId, electricityReadings);
	}
}
