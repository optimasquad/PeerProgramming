
package uk.tw.energy.price.store;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.stream.StreamSupport;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.AbstractEnvironment;
import org.springframework.core.io.support.ResourcePropertySource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import uk.tw.energy.domain.ElectricityReading;
import uk.tw.energy.domain.PricePlan;
import uk.tw.energy.generator.ElectricityReadingsGenerator;
import uk.tw.energy.exception.InvalidPricePlanException;


/**
 * @author JATIN MAHAJAN
 *
 */
@Component
public class SmartMeter implements SuperMeter {

	@Autowired
	private AbstractEnvironment environment;

	@Autowired
	private PricePlanStore pricePlanStore;

	private final static Map<String, PricePlan> smartMeterToPricePlanAccounts = new HashMap<>();

	private final static Map<String, List<ElectricityReading>> readings = new HashMap<>();

	@PostConstruct
	private void loadSmartMeters() {

		Properties props = asProperties("properties/smartMeter.properties");

		for (Map.Entry<Object, Object> meter : props.entrySet()) {
			PricePlan plan = createPricePlanForMeterId((String) meter.getValue());
			smartMeterToPricePlanAccounts.put((String) meter.getKey(), plan);
		}
		createPerMeterElectricityReadings();
	}

	private Properties asProperties(String fileName) {
		return StreamSupport.stream(((AbstractEnvironment) environment).getPropertySources().spliterator(), false)
				.filter(ps -> ps instanceof ResourcePropertySource).map(ps -> (ResourcePropertySource) ps)
				.filter(rps -> rps.getName().contains(fileName))
				.collect(Properties::new, (props, rps) -> props.putAll(rps.getSource()), Properties::putAll);
	}

	/**
	 * Get Price Plan for the Meter
	 * @param meterName
	 * @return
	 */
	private PricePlan createPricePlanForMeterId(String meterName) {
		PricePlan pricePlan = pricePlanStore.getPricePlan(meterName);
		if (null == pricePlan) {
			throw new InvalidPricePlanException(HttpStatus.BAD_REQUEST,
					"The Price Plan Not configured against the meterName" + meterName);
		}
		return pricePlan;

	}

	/**
	 * This method is used to create the Electricity Readings Per Meter
	 * @return
	 */
	private Map<String, List<ElectricityReading>> createPerMeterElectricityReadings() {
		smartMeterToPricePlanAccounts.keySet()
				.forEach(smartMeterId -> readings.put(smartMeterId, ElectricityReadingsGenerator.generate(20)));
		return readings;
	}

	@Override
	public PricePlan getPricePlanForMeterId(String smartMeterId) {
		return smartMeterToPricePlanAccounts.get(smartMeterId);
	}

	@Override
	public List<ElectricityReading> getMeterReadingForMeterId(String meterId) {
		return readings.get(meterId);
	}

	@Override
	public void storeMeterReadings(String meterId, List<ElectricityReading> electricityReadings) {
		if (!readings.containsKey(meterId)) {
			readings.put(meterId, new ArrayList<>());
		}
		readings.get(meterId).addAll(electricityReadings);

	}

}
