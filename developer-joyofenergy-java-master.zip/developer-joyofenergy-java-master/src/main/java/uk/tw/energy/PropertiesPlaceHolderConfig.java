
package uk.tw.energy;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.support.DefaultConversionService;

/**
 * @author JATIN MAHAJAN
 *
 */
@Configuration
@PropertySources({ @PropertySource("classpath:properties/pricePlan.properties"),
		@PropertySource("classpath:properties/smartMeter.properties") })
public class PropertiesPlaceHolderConfig {

	@Bean
	public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
		return new PropertySourcesPlaceholderConfigurer();
	}

	@Bean
	public ConversionService conversionService() {
		return new DefaultConversionService();
	}

}
