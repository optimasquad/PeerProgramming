package uk.tw.energy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import uk.tw.energy.domain.PricePlan;
import uk.tw.energy.exception.InvalidPricePlanException;
import uk.tw.energy.price.store.SuperMeter;

@Service
public class AccountService {

	@Autowired
	private SuperMeter meter;

	public String getPricePlanIdForSmartMeterId(String smartMeterId) throws InvalidPricePlanException {

		PricePlan pricePlan = meter.getPricePlanForMeterId(smartMeterId);

		if (null == pricePlan) {
			throw new InvalidPricePlanException(HttpStatus.BAD_REQUEST,"Price Plan does not exists for smartMeterId " + smartMeterId);
		}
		return pricePlan.getPlanName();
	}
}
