/**
 * 
 */
package uk.tw.energy.price.store;

import uk.tw.energy.domain.PricePlan;

/**
 * @author JATIN MAHAJAN
 *
 */
public interface Plan {
	
	public PricePlan getPricePlan();

}
