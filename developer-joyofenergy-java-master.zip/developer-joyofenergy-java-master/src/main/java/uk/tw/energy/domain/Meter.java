package uk.tw.energy.domain;

/**
 * This class represents a Meter consist of MeterReadings and PricePlans information
 */
public class Meter {

    private MeterReadings meterReadings;

    private PricePlan pricePlan;

    public Meter(MeterReadings meterReadings, PricePlan pricePlan) {
        this.meterReadings = meterReadings;
        this.pricePlan = pricePlan;
    }

    public PricePlan getPricePlan() {
        return pricePlan;
    }

    public MeterReadings getMeterReadings() {
        return meterReadings;
    }
}
