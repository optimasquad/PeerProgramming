package uk.tw.energy.price.store;

import java.util.List;

import uk.tw.energy.domain.ElectricityReading;
import uk.tw.energy.domain.PricePlan;

public interface SuperMeter {

	PricePlan getPricePlanForMeterId(String meterId);

	List<ElectricityReading> getMeterReadingForMeterId(String meterId);

	void storeMeterReadings(String meterId, List<ElectricityReading> electricityReadings);

}
