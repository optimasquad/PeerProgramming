package uk.tw.energy.domain;

import java.math.BigDecimal;
import java.util.Map;

public class PricePlanComparisonsPerPricePlanId {

    private Map<String, BigDecimal> pricePlanComparisons;

    private String pricePlanId;

    public PricePlanComparisonsPerPricePlanId(String pricePlanId,Map<String, BigDecimal> pricePlanComparisons) {
        this.pricePlanComparisons = pricePlanComparisons;
        this.pricePlanId = pricePlanId;
    }

    public Map<String, BigDecimal> getPricePlanComparisons() {
        return pricePlanComparisons;
    }

    public String getPricePlanId() {
        return pricePlanId;
    }
}
