
package uk.tw.energy.price.store;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import uk.tw.energy.constants.JoyEnergyConstants;
import uk.tw.energy.domain.PricePlan;

/**
 * @author JATIN MAHAJAN
 *
 */

@Component
public class PricePlanStore {

	@Autowired
	private MostEvilPricePlan mostEvilPricePlan;

	@Autowired
	private RenewablePricePlan renewablePricePlan;

	@Autowired
	private StandaradPricePlan standaradPricePlan;

	//getPricePlan on basis of requested planType
	public PricePlan getPricePlan(String planType) {
		if (JoyEnergyConstants.MOST_EVIL_PRICE_PLAN_ID.equalsIgnoreCase(planType)) {
			return mostEvilPricePlan.getPricePlan();
		} else if (JoyEnergyConstants.RENEWABLES_PRICE_PLAN_ID.equalsIgnoreCase(planType)) {
			return renewablePricePlan.getPricePlan();
		} else if (JoyEnergyConstants.STANDARD_PRICE_PLAN_ID.equalsIgnoreCase(planType)) {
			return standaradPricePlan.getPricePlan();
		}
		return null;
	}

	/**
	 * Get List of available PricePlans
	 * @return
	 */
	public List<PricePlan> getAvailablePricePlans() {
		List<String> plans = Arrays.asList(JoyEnergyConstants.MOST_EVIL_PRICE_PLAN_ID,
				JoyEnergyConstants.RENEWABLES_PRICE_PLAN_ID, JoyEnergyConstants.STANDARD_PRICE_PLAN_ID);
		return plans.stream().map(this::getPricePlan).map(plan -> plan).collect(Collectors.toList());

	}
}
