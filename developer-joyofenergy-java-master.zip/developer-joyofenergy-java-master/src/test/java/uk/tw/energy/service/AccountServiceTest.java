package uk.tw.energy.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import uk.tw.energy.domain.PricePlan;
import uk.tw.energy.exception.InvalidPricePlanException;
import uk.tw.energy.price.store.SmartMeter;

import java.math.BigDecimal;
import java.util.Collections;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
public class AccountServiceTest {
	private static final String PRICE_PLAN_ID = "price-plan-id";
	private static final String SMART_METER_ID = "smart-meter-id";

	@Mock
	private SmartMeter meter;

	@InjectMocks
	private AccountService accountService;

	@Test
	public void givenTheSmartMeterIdReturnsThePricePlanId() throws Exception {
		PricePlan pricePlan=new PricePlan(PRICE_PLAN_ID,"Green Supplier", BigDecimal.ONE, Collections.emptyList());
		Mockito.when(meter.getPricePlanForMeterId(Mockito.anyString())).thenReturn(pricePlan);
		assertThat(accountService.getPricePlanIdForSmartMeterId(SMART_METER_ID)).isEqualTo(PRICE_PLAN_ID);
	}

	@Test
	public void givenTheSmartMeterIdPlanNotFound() throws InvalidPricePlanException {
		Mockito.when(meter.getPricePlanForMeterId(Mockito.anyString())).thenReturn(null);
		InvalidPricePlanException exception = assertThrows(InvalidPricePlanException.class, () -> {
			accountService.getPricePlanIdForSmartMeterId(SMART_METER_ID);
		});
		assertThat(HttpStatus.BAD_REQUEST).isEqualTo(exception.getHttpStatus());
	}

}
