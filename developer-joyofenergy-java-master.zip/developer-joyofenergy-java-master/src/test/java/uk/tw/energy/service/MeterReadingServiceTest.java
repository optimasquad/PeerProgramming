package uk.tw.energy.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.tw.energy.domain.ElectricityReading;
import uk.tw.energy.price.store.SuperMeter;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Optional;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@ExtendWith(MockitoExtension.class)
public class MeterReadingServiceTest {

	@Mock
	private SuperMeter meter;

	@InjectMocks
	private MeterReadingService meterReadingService;

	@Test
	public void givenMeterReadingThatExistsShouldReturnMeterReadings() {
		ElectricityReading electricityReading=new ElectricityReading(Instant.EPOCH, BigDecimal.ONE);
		Mockito.when(meter.getMeterReadingForMeterId(Mockito.anyString())).thenReturn(Collections.singletonList(electricityReading));
		assertThat(meterReadingService.getReadings("unknown-id").get().size()).isEqualTo(1);
	}

	@Test
	public void givenMeterIdThatDoesNotExistShouldReturnNull() {
		Mockito.when(meter.getMeterReadingForMeterId(Mockito.anyString())).thenReturn(Collections.emptyList());
		assertThat(meterReadingService.getReadings("random-id")).isEqualTo(Optional.of(new ArrayList<>()));
	}

	@Test
	public void givenMeterReadingAndGetItStored() {
		Mockito.lenient().doNothing().when(meter).storeMeterReadings("random-id", new ArrayList<>());
		meterReadingService.storeReadings("random-id", new ArrayList<>());
		Mockito.verify(meter, Mockito.times(1)).storeMeterReadings("random-id", new ArrayList<>());
	}
}
