package uk.tw.energy.price.store;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@SpringBootTest
@TestPropertySource(locations = { "classpath:properties/pricePlan.properties"})
public class StandardPricePlanTest {

    @Value("${standard.planName}")
    private String planName;

    @Value("${standard.energySupplier}")
    private String energySupplier;

    @Value("#{new Integer('${standard.unitRate}')}")
    private Integer unitRate;

    @Test
    public void testInjectedProperties() {
        assertThat(planName).isEqualTo("price-plan-2");
        assertThat(energySupplier).isEqualTo("Power for Everyone");
        assertThat(unitRate).isEqualTo(1);
    }
}
