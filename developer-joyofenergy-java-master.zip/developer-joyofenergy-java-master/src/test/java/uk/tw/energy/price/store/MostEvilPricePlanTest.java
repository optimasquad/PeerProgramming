package uk.tw.energy.price.store;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@SpringBootTest
@TestPropertySource(locations = { "classpath:properties/pricePlan.properties"})
public class MostEvilPricePlanTest {

    @Value("${evil.planName}")
    private String planName;

    @Value("${evil.energySupplier}")
    private String energySupplier;

    @Value("#{new Integer('${evil.unitRate}')}")
    private Integer unitRate;

    @Test
    public void testInjectedProperties() {
        assertThat(planName).isEqualTo("price-plan-0");
        assertThat(energySupplier).isEqualTo("Dr Evil's Dark Energy");
        assertThat(unitRate).isEqualTo(10);
    }

}
