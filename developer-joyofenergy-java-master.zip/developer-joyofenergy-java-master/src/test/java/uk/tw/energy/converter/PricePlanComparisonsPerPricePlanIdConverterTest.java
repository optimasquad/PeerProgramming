package uk.tw.energy.converter;

import javafx.util.Pair;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.tw.energy.domain.PricePlanComparisonsPerPricePlanId;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@ExtendWith(MockitoExtension.class)
public class PricePlanComparisonsPerPricePlanIdConverterTest {

    private static final String PRICE_PLAN_0 = "price-plan-0";

    @InjectMocks
    private PricePlanComparisonsPerPricePlanIdConverter pricePlanComparisonsPerPricePlanIdConverter;

    @Test
    public void testConvertToPricePlanComparisons() {
        Map<String, BigDecimal> pricePlanCost = new HashMap<>();
        pricePlanCost.put("price-plan-0", BigDecimal.ONE);
        Pair<String, Map<String, BigDecimal>> pricePlanIdPerPricePlanCost = new Pair<String, Map<String, BigDecimal>>(PRICE_PLAN_0, pricePlanCost);
        PricePlanComparisonsPerPricePlanId pricePlanComparisonsPerPricePlanId = pricePlanComparisonsPerPricePlanIdConverter.convert(pricePlanIdPerPricePlanCost);
        assertThat(pricePlanComparisonsPerPricePlanId.getPricePlanId()).isEqualTo("price-plan-0");
    }


}
