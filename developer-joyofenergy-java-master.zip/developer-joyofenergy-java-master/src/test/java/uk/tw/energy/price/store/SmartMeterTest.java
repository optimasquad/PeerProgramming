package uk.tw.energy.price.store;

import org.assertj.core.data.Percentage;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.AbstractEnvironment;
import org.springframework.test.context.TestPropertySource;
import uk.tw.energy.builders.MeterReadingsBuilder;
import uk.tw.energy.domain.ElectricityReading;
import uk.tw.energy.domain.MeterReadings;
import uk.tw.energy.domain.PricePlan;

import java.math.BigDecimal;
import java.util.List;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@SpringBootTest
@TestPropertySource(locations = {"classpath:properties/smartMeter.properties","classpath:properties/pricePlan.properties"})
@ExtendWith(MockitoExtension.class)
public class SmartMeterTest {

    private static final String SMART_METER_0 = "smart-meter-0";

    @Mock
    private AbstractEnvironment environment;

    @Mock
    private PricePlanStore pricePlanStore;

    @InjectMocks
    private SmartMeter smartMeter;

    @Test
    public void givenMeterIdGetPricePlan() {
        PricePlan pricePlan=smartMeter.getPricePlanForMeterId(SMART_METER_0);
        assertThat(pricePlan.getPlanName().equals("price-plan-0"));
        assertThat(pricePlan.getEnergySupplier().equals("Dr Evil's Dark Energy"));
        assertThat(pricePlan.getUnitRate().equals(BigDecimal.TEN));
    }

    @Test
    public void givenMeterIdThenReturnMeterReadings(){
        List<ElectricityReading>readings=smartMeter.getMeterReadingForMeterId(SMART_METER_0);
        assertThat(readings.size()).isCloseTo(20, Percentage.withPercentage(50));
    }

    @Test
    public void givenMeterIdAndMeterReadingsNotPresentThenStoreIt(){

        MeterReadings meterReadings = new MeterReadingsBuilder().setSmartMeterId("smart-meter-100")
                .generateElectricityReadings()
                .build();

        smartMeter.storeMeterReadings(meterReadings.getSmartMeterId(),meterReadings.getElectricityReadings());
        assertThat(smartMeter.getMeterReadingForMeterId("smart-meter-100").size()).isEqualTo(5);
    }

    @Test
    public void givenMeterIdAndMeterReadingsPresentThenStoreIt(){

        MeterReadings meterReadings = new MeterReadingsBuilder().setSmartMeterId("smart-meter-0")
                .generateElectricityReadings()
                .build();

        smartMeter.storeMeterReadings(meterReadings.getSmartMeterId(),meterReadings.getElectricityReadings());
        assertThat(smartMeter.getMeterReadingForMeterId("smart-meter-0")).isNotNull();
    }
}
