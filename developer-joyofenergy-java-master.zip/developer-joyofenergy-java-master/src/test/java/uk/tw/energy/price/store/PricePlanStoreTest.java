package uk.tw.energy.price.store;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.tw.energy.constants.JoyEnergyConstants;
import uk.tw.energy.domain.PricePlan;

import java.math.BigDecimal;
import java.util.Collections;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@ExtendWith(MockitoExtension.class)
public class PricePlanStoreTest {

    @Mock
    private MostEvilPricePlan mostEvilPricePlan;

    @Mock
    private RenewablePricePlan renewablePricePlan;

    @Mock
    private StandaradPricePlan standaradPricePlan;

    @InjectMocks
    private PricePlanStore pricePlanStore;

    @Test
    public void givenMostEvilPlanTypeShouldReturnPricePlan() {
        PricePlan pricePlan = new PricePlan("price-plan-0", "Dr Evil", BigDecimal.TEN, Collections.emptyList());
        Mockito.when(mostEvilPricePlan.getPricePlan()).thenReturn(pricePlan);
        PricePlan pricePlanType = pricePlanStore.getPricePlan(JoyEnergyConstants.MOST_EVIL_PRICE_PLAN_ID);
        assertThat(pricePlanType.getPlanName()).isEqualTo("price-plan-0");
        assertThat(pricePlanType.getEnergySupplier()).isEqualTo("Dr Evil");
        assertThat(pricePlanType.getUnitRate()).isEqualTo(BigDecimal.TEN);
    }

    @Test
    public void givenRenewablePlanTypeShouldReturnPricePlan() {
        PricePlan pricePlan = new PricePlan("price-plan-1", "The Green Eco", BigDecimal.valueOf(2), Collections.emptyList());
        Mockito.when(renewablePricePlan.getPricePlan()).thenReturn(pricePlan);
        PricePlan pricePlanType = pricePlanStore.getPricePlan(JoyEnergyConstants.RENEWABLES_PRICE_PLAN_ID);
        assertThat(pricePlanType.getPlanName()).isEqualTo("price-plan-1");
        assertThat(pricePlanType.getEnergySupplier()).isEqualTo("The Green Eco");
        assertThat(pricePlanType.getUnitRate()).isEqualTo(BigDecimal.valueOf(2));
    }

    @Test
    public void givenStandardPlanTypeShouldReturnPricePlan() {
        PricePlan pricePlan = new PricePlan("price-plan-2", "Power for Everyone", BigDecimal.ONE, Collections.emptyList());
        Mockito.when(standaradPricePlan.getPricePlan()).thenReturn(pricePlan);
        PricePlan pricePlanType = pricePlanStore.getPricePlan(JoyEnergyConstants.STANDARD_PRICE_PLAN_ID);
        assertThat(pricePlanType.getPlanName()).isEqualTo("price-plan-2");
        assertThat(pricePlanType.getEnergySupplier()).isEqualTo("Power for Everyone");
        assertThat(pricePlanType.getUnitRate()).isEqualTo(BigDecimal.ONE);
    }

    @Test
    public void givenInvalidPlanTypeShouldReturnNull() {
        PricePlan pricePlanType = pricePlanStore.getPricePlan("testing");
        assertThat(pricePlanType).isNull();
    }
}
