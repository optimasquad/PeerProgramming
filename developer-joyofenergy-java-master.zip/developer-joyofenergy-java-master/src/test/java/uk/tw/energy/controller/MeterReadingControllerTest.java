package uk.tw.energy.controller;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import uk.tw.energy.builders.MeterReadingsBuilder;
import uk.tw.energy.domain.ElectricityReading;
import uk.tw.energy.domain.MeterReadings;
import uk.tw.energy.service.MeterReadingService;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@ExtendWith(MockitoExtension.class)
public class MeterReadingControllerTest {
    private static final String SMART_METER_ID = "10101010";

    @InjectMocks
    private MeterReadingController meterReadingController;

    @Mock
    private MeterReadingService meterReadingService;

    @Mock
    private List<ElectricityReading> mockedList;

    @Test
    public void givenNoMeterIdIsSuppliedWhenStoringShouldReturnErrorResponse() {
        MeterReadings meterReadings = new MeterReadings(null, Collections.emptyList());
        assertThat(meterReadingController.storeReadings(meterReadings).getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
    }

    @Test
    public void givenEmptyMeterReadingShouldReturnErrorResponse() {
        MeterReadings meterReadings = new MeterReadings(SMART_METER_ID, Collections.emptyList());
        assertThat(meterReadingController.storeReadings(meterReadings).getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
    }

    @Test
    public void givenNullReadingsAreSuppliedWhenStoringShouldReturnErrorResponse() {
        MeterReadings meterReadings = new MeterReadings(SMART_METER_ID, null);
        assertThat(meterReadingController.storeReadings(meterReadings).getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
    }

    @Test
    public void givenMultipleBatchesOfMeterReadingsShouldStore() {
        MeterReadings meterReadings = new MeterReadingsBuilder().setSmartMeterId(SMART_METER_ID)
                .generateElectricityReadings()
                .build();

        MeterReadings otherMeterReadings = new MeterReadingsBuilder().setSmartMeterId(SMART_METER_ID)
                .generateElectricityReadings()
                .build();

        mockedList.addAll(meterReadings.getElectricityReadings());
        mockedList.addAll(otherMeterReadings.getElectricityReadings());

        ArgumentCaptor<List> argumentCaptor = ArgumentCaptor.forClass(List.class);

        Mockito.lenient().doNothing().when(meterReadingService).storeReadings(Mockito.anyString(),
                Mockito.anyList());

        meterReadingController.storeReadings(meterReadings);
        meterReadingController.storeReadings(otherMeterReadings);

        Mockito.verify(mockedList, Mockito.times(2)).addAll(argumentCaptor.capture());
        List<ElectricityReading> expectedElectricityReadings = new ArrayList<>();
        expectedElectricityReadings.addAll(meterReadings.getElectricityReadings());
        expectedElectricityReadings.addAll(otherMeterReadings.getElectricityReadings());
        List allValues = (List) argumentCaptor.getAllValues().stream().flatMap(List::stream).collect(Collectors.toList());
        assertThat(allValues.size()).isEqualTo(expectedElectricityReadings.size());
    }

    @Test
    public void givenMeterReadingsAssociatedWithTheUserShouldStoreAssociatedWithUser() {
        MeterReadings meterReadings = new MeterReadingsBuilder().setSmartMeterId(SMART_METER_ID)
                .generateElectricityReadings()
                .build();

        MeterReadings otherMeterReadings = new MeterReadingsBuilder().setSmartMeterId("00001")
                .generateElectricityReadings()
                .build();

        mockedList.addAll(meterReadings.getElectricityReadings());
        mockedList.addAll(otherMeterReadings.getElectricityReadings());

        ArgumentCaptor<List> argumentCaptor = ArgumentCaptor.forClass(List.class);

        Mockito.lenient().doNothing().when(meterReadingService).storeReadings(Mockito.anyString(),
                Mockito.anyList());

        meterReadingController.storeReadings(meterReadings);
        meterReadingController.storeReadings(otherMeterReadings);

        Mockito.verify(mockedList, Mockito.times(2)).addAll(argumentCaptor.capture());

        List<ElectricityReading> expectedElectricityReadings = new ArrayList<>();
        expectedElectricityReadings.addAll(meterReadings.getElectricityReadings());
        expectedElectricityReadings.addAll(otherMeterReadings.getElectricityReadings());
        List response = (List) argumentCaptor.getAllValues().stream().flatMap(List::stream).collect(Collectors.toList());
        assertThat(response.size()).isEqualTo(expectedElectricityReadings.size());
    }

    @Test
    public void givenMeterIdThatIsNotRecognisedShouldReturnNotFound() {
        assertThat(meterReadingController.readReadings(SMART_METER_ID).getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
    }

    @Test
    public void givenMeterIdReturnListOfElectricityReading() {
        List<ElectricityReading>readings=new ArrayList<>();
        ElectricityReading electricityReading=new ElectricityReading(Instant.now(), BigDecimal.ONE);
        readings.add(electricityReading);
        List<ElectricityReading>expectedReadings=new ArrayList<>();
        expectedReadings.add(electricityReading);
        Mockito.when(meterReadingService.getReadings(Mockito.anyString())).thenReturn(Optional.of(readings));
        assertThat(meterReadingController.readReadings(SMART_METER_ID).getBody()).isEqualTo(expectedReadings);
    }
}
