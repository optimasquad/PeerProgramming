package uk.tw.energy.price.store;


import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@SpringBootTest
@TestPropertySource(locations = { "classpath:properties/pricePlan.properties"})
public class RenewablePricePlanTest {

    @Value("${renewable.planName}")
    private String planName;

    @Value("${renewable.energySupplier}")
    private String energySupplier;

    @Value("#{new Integer('${renewable.unitRate}')}")
    private Integer unitRate;

    @Test
    public void testInjectedProperties() {
        assertThat(planName).isEqualTo("price-plan-1");
        assertThat(energySupplier).isEqualTo("The Green Eco");
        assertThat(unitRate).isEqualTo(2);
    }

}
