package uk.tw.energy.controller;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import uk.tw.energy.converter.PricePlanComparisonsPerPricePlanIdConverter;
import uk.tw.energy.domain.PricePlanComparisonsPerPricePlanId;
import uk.tw.energy.service.AccountService;
import uk.tw.energy.service.MeterReadingService;
import uk.tw.energy.service.PricePlanService;

import java.math.BigDecimal;
import java.util.*;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@ExtendWith(MockitoExtension.class)
public class PricePlanComparatorControllerTest {
    private static final String PRICE_PLAN_1_ID = "test-supplier";
    private static final String PRICE_PLAN_2_ID = "best-supplier";
    private static final String PRICE_PLAN_3_ID = "second-best-supplier";
    private static final String SMART_METER_ID = "smart-meter-id";

    @InjectMocks
    private PricePlanComparatorController controller;

    @Mock
    private MeterReadingService meterReadingService;

    @Mock
    private PricePlanService pricePlanService;

    @Mock
    private AccountService accountService;

    @Mock
    private PricePlanComparisonsPerPricePlanIdConverter pricePlanComparisonsPerPricePlanIdConverter;

    @Test
    public void shouldCalculateCostForMeterReadingsForEveryPricePlan() {

        Map<String, BigDecimal> pricePlanCost = new HashMap<>();
        pricePlanCost.put(PRICE_PLAN_1_ID, BigDecimal.valueOf(100.0));
        pricePlanCost.put(PRICE_PLAN_2_ID, BigDecimal.valueOf(10.0));
        pricePlanCost.put(PRICE_PLAN_3_ID, BigDecimal.valueOf(20.0));
        PricePlanComparisonsPerPricePlanId pricePlanComparisonsPerPricePlanId = new PricePlanComparisonsPerPricePlanId(
                PRICE_PLAN_1_ID, pricePlanCost);
        Mockito.when(accountService.getPricePlanIdForSmartMeterId(Mockito.anyString())).thenReturn(PRICE_PLAN_1_ID);
        Mockito.when(pricePlanService.getConsumptionCostOfElectricityReadingsForEachPricePlan(Mockito.anyString()))
                .thenReturn(Optional.of(pricePlanCost));
        Mockito.when(pricePlanComparisonsPerPricePlanIdConverter.convert(Mockito.any()))
                .thenReturn(pricePlanComparisonsPerPricePlanId);

        Map<String, BigDecimal> expectedPricePlanToCost = new HashMap<>();
        expectedPricePlanToCost.put(PRICE_PLAN_1_ID, BigDecimal.valueOf(100.0));
        expectedPricePlanToCost.put(PRICE_PLAN_2_ID, BigDecimal.valueOf(10.0));
        expectedPricePlanToCost.put(PRICE_PLAN_3_ID, BigDecimal.valueOf(20.0));

        PricePlanComparisonsPerPricePlanId expectedPricePlanComparisonsPerPricePlanId = new PricePlanComparisonsPerPricePlanId(
                PRICE_PLAN_1_ID, expectedPricePlanToCost);

        assertThat(controller.calculatedCostForEachPricePlan(SMART_METER_ID).getBody().getPricePlanId()).isEqualTo(expectedPricePlanComparisonsPerPricePlanId
                .getPricePlanId());
    }

    @Test
    public void shouldRecommendCheapestPricePlansNoLimitForMeterUsage() throws Exception {

        Map<String, BigDecimal> pricePlanToCost = new HashMap<>();
        pricePlanToCost.put(PRICE_PLAN_2_ID, BigDecimal.valueOf(38.0));
        pricePlanToCost.put(PRICE_PLAN_3_ID, BigDecimal.valueOf(76.0));
        pricePlanToCost.put(PRICE_PLAN_1_ID, BigDecimal.valueOf(380.0));

        Mockito.when(pricePlanService.getConsumptionCostOfElectricityReadingsForEachPricePlan(Mockito.anyString()))
                .thenReturn(Optional.of(pricePlanToCost));

        List<Map.Entry<String, BigDecimal>> expectedPricePlanToCost = new ArrayList<>();
        expectedPricePlanToCost.add(new AbstractMap.SimpleEntry<>(PRICE_PLAN_2_ID, BigDecimal.valueOf(38.0)));
        expectedPricePlanToCost.add(new AbstractMap.SimpleEntry<>(PRICE_PLAN_3_ID, BigDecimal.valueOf(76.0)));
        expectedPricePlanToCost.add(new AbstractMap.SimpleEntry<>(PRICE_PLAN_1_ID, BigDecimal.valueOf(380.0)));

        assertThat(controller.recommendCheapestPricePlans(SMART_METER_ID, null).getBody()).isEqualTo(expectedPricePlanToCost);
    }


    @Test
    public void shouldRecommendLimitedCheapestPricePlansForMeterUsage() throws Exception {
        Map<String, BigDecimal> pricePlanToCost = new HashMap<>();
        pricePlanToCost.put(PRICE_PLAN_2_ID, BigDecimal.valueOf(16.7));
        pricePlanToCost.put(PRICE_PLAN_3_ID, BigDecimal.valueOf(33.4));

        Mockito.when(pricePlanService.getConsumptionCostOfElectricityReadingsForEachPricePlan(Mockito.anyString()))
                .thenReturn(Optional.of(pricePlanToCost));

        List<Map.Entry<String, BigDecimal>> expectedPricePlanToCost = new ArrayList<>();
        expectedPricePlanToCost.add(new AbstractMap.SimpleEntry<>(PRICE_PLAN_2_ID, BigDecimal.valueOf(16.7)));
        expectedPricePlanToCost.add(new AbstractMap.SimpleEntry<>(PRICE_PLAN_3_ID, BigDecimal.valueOf(33.4)));

        assertThat(controller.recommendCheapestPricePlans(SMART_METER_ID, 2).getBody()).isEqualTo(expectedPricePlanToCost);
    }

    @Test
    public void shouldRecommendCheapestPricePlansMoreThanLimitAvailableForMeterUsage() throws Exception {

        Map<String, BigDecimal> pricePlanToCost = new HashMap<>();
        pricePlanToCost.put(PRICE_PLAN_2_ID, BigDecimal.valueOf(14.0));
        pricePlanToCost.put(PRICE_PLAN_3_ID, BigDecimal.valueOf(28.0));
        pricePlanToCost.put(PRICE_PLAN_1_ID, BigDecimal.valueOf(140.0));

        Mockito.when(pricePlanService.getConsumptionCostOfElectricityReadingsForEachPricePlan(Mockito.anyString()))
                .thenReturn(Optional.of(pricePlanToCost));

        List<Map.Entry<String, BigDecimal>> expectedPricePlanToCost = new ArrayList<>();
        expectedPricePlanToCost.add(new AbstractMap.SimpleEntry<>(PRICE_PLAN_2_ID, BigDecimal.valueOf(14.0)));
        expectedPricePlanToCost.add(new AbstractMap.SimpleEntry<>(PRICE_PLAN_3_ID, BigDecimal.valueOf(28.0)));
        expectedPricePlanToCost.add(new AbstractMap.SimpleEntry<>(PRICE_PLAN_1_ID, BigDecimal.valueOf(140.0)));

        assertThat(controller.recommendCheapestPricePlans(SMART_METER_ID, 5).getBody()).isEqualTo(expectedPricePlanToCost);
    }

    @Test
    public void givenNoMatchingMeterIdShouldReturnNotFound() {
        assertThat(controller.calculatedCostForEachPricePlan("not-found").getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
    }

    @Test
    public void givenNoMatchingMeterIdShouldReturnNotFoundRecommendedPricePlans() {
        assertThat(controller.recommendCheapestPricePlans("not-found", null).getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
    }

}